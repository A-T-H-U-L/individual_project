const express=require('express');
const app= express();
const jwt=require('jsonwebtoken');

app.listen(3000);
app.use(express.json())

const post=[{
    username:"athul",
    password:"athul1"
},
{
    username:"arun",
    password:"arun1"
}]


app.get('/posts',(req,res)=>{
    res.json(post)
})

app.post('/login',(req,res)=>{
    // Authenticate the user
  const username=req.body.username;
  const user={name:username}
  const accessToken=jwt.sign(user,process.env.ACCESS_TOKEN_SECERET)
  res.json

})